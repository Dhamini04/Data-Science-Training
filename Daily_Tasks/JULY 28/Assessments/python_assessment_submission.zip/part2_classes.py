
# Part 2: Classes and Inheritance

class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def display(self):
        print(f"Name: {self.name}, Age: {self.age}")

class Employee(Person):
    def __init__(self, name, age, employee_id, department):
        super().__init__(name, age)
        self.employee_id = employee_id
        self.department = department

    def display(self):
        super().display()
        print(f"Employee ID: {self.employee_id}, Department: {self.department}")

class Vehicle:
    def drive(self):
        print("Driving a vehicle")

class Car(Vehicle):
    def drive(self):
        print("Driving a car")

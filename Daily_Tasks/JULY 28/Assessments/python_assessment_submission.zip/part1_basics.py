
# Part 1: Basics

# Q1. Prime number checker
def is_prime(n):
    if n <= 1:
        return False
    for i in range(2, int(n**0.5)+1):
        if n % i == 0:
            return False
    return True

# Q2. Palindrome checker
def check_palindrome():
    s = input("Enter a string: ")
    reversed_s = s[::-1]
    print("Palindrome" if s == reversed_s else "Not a palindrome")

# Q3. List processing
def process_list(nums):
    unique_sorted = sorted(set(nums))
    if len(unique_sorted) >= 2:
        print("Second largest:", unique_sorted[-2])
    else:
        print("Not enough unique elements.")
